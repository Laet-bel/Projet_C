# Projet_C
Dans le dossier data il faudra inclure les deux dossiers d'images : 
- Ground truth
- Source images